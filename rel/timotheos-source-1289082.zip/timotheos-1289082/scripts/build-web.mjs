/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Edmund P. Valdez */
// Builds dist/: the screens of Timotheos (app/renderer), the worker that runs the former Electron main process
// (app/main.js + app/lib) with the shims in tauri-shim/, and the page-side host.
import { build } from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(dist, { recursive: true });

const shim = f => path.join(root, 'tauri-shim', f);
await build({
  entryPoints: [shim('worker-entry.js')], outfile: path.join(dist, 'worker.js'), bundle: true, format: 'iife', platform: 'browser', target: 'es2020',
  alias: { fs: shim('fs.js'), os: shim('os.js'), zlib: shim('zlib.js'), crypto: shim('empty.js'), electron: shim('electron.js'), 'node:sqlite': shim('sqlite.js'), path: 'pathe', 'node:path': 'pathe' },
  inject: [shim('inject.js')], define: { __dirname: '"/app"', global: 'globalThis' }, logLevel: 'warning', minify: false,
});
await build({
  entryPoints: [shim('host.js')], outfile: path.join(dist, 'tauri-host.js'), bundle: true, format: 'iife', platform: 'browser', target: 'es2020', logLevel: 'warning', minify: true,
});
fs.cpSync(path.join(root, 'app', 'renderer'), dist, { recursive: true });
fs.copyFileSync(shim('host.css'), path.join(dist, 'host.css'));
// the build number of a GitHub build (Check for updates offers a newer build of the same version)
{ const n = parseInt(process.env.GITHUB_RUN_NUMBER || '0', 10) || 0, sha = String(process.env.GITHUB_SHA || '').slice(0, 7).replace(/[^0-9a-f]/g, '');
  fs.writeFileSync(path.join(dist, 'buildinfo.js'), `/* SPDX-License-Identifier: AGPL-3.0-or-later */\nwindow.TIMOTHEOS_BUILD = { n: ${n}, sha: '${sha}' };\n`); }
// the archive reader: 7-Zip as WebAssembly (lib/archive.js fetches it next to worker.js)
fs.copyFileSync(path.join(root, 'node_modules', '7z-wasm', '7zz.wasm'), path.join(dist, '7zz.wasm'));
// the licence texts travel with the program (AGPL-3.0-or-later; shown in About → Legal)
fs.mkdirSync(path.join(dist, 'legal'), { recursive: true });
for (const f of ['LICENSE', 'THIRD-PARTY-LICENSES.md', 'NOTICE']) fs.copyFileSync(path.join(root, f), path.join(dist, 'legal', f.replace(/\.md$/, '') + '.txt'));

const inject = '<link rel="stylesheet" href="host.css"><script src="tauri-host.js"></script>\n';
let html = fs.readFileSync(path.join(dist, 'index.html'), 'utf8');
if (!html.includes('tauri-host.js')) html = html.replace(/<script src="icons\.js"><\/script>/, inject + '<script src="icons.js"></script>');
if (!html.includes('tauri-host.js')) throw new Error('index.html: place for the host script not found');
fs.writeFileSync(path.join(dist, 'index.html'), html);
console.log('dist ready:', fs.readdirSync(dist).length, 'entries');
